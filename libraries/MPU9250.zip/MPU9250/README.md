MPU9250
=======

C++ MPU9250 Driver for Arduino

datasheet can be forund here: http://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0CCgQFjAA&url=http%3A%2F%2Fwww.invensense.com%2Fmems%2Fgyro%2Fdocuments%2FRM-MPU-9250A-00.pdf&ei=OChOU_rpNMig8AGn7oC4Dg&usg=AFQjCNFbFLP9rQVhZPSQbAs0ga0QC4mRZw&bvm=bv.64764171,d.b2U

reads accelerometer, gyroscopic and magnetic data in 3D giving 9 Degrees of Freedom